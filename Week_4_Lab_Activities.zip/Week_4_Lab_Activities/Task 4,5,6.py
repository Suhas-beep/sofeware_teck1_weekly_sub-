from PIL import Image, ImageEnhance, ImageFilter



#Task 4: Understand Pixels and Colors

image = Image.open("Assets/1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG")
print(image.getpixel((55,55)))
red_grayscale_image = image.getchannel('R')
blue_grayscale_image = image.getchannel('B')

#Task 5: Image Enhancement
image = ImageEnhance.Color(image)
image = image.enhance(70)

image= ImageEnhance.Sharpness(image)
image = image.enhance(60)

#Task 6: Image Filtering
image = image.filter(ImageFilter.BoxBlur(radius=50))
image = image.filter(ImageFilter.CONTOUR)


red_grayscale_image.show()
blue_grayscale_image.show()

image.show()

#Insect no. 2

sec_image = Image.open("Assets/1_Limniu 2021_1_2021_06_02-13-08-37-941.PNG")

print(sec_image.getpixel((0,0)))
red_grayscale_sec_image = sec_image.getchannel('R')
blue_grayscale_sec_image = sec_image.getchannel('B')

sec_image = ImageEnhance.Contrast(sec_image)
sec_image = sec_image.enhance(2)

sec_image = ImageEnhance.Sharpness(sec_image)
sec_image = sec_image.enhance(0)

sec_image = sec_image.filter(ImageFilter.BLUR)
sec_image = sec_image.filter(ImageFilter.UnsharpMask(radius=30))

red_grayscale_sec_image.show()
blue_grayscale_sec_image.show()

sec_image.show()


#Insect no. 3

third_image = Image.open("Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG")

print(third_image.getpixel((0,0)))
red_grayscale_third_image = third_image.getchannel('R')
blue_grayscale_third_image = third_image.getchannel('B')

third_image = ImageEnhance.Color(third_image)
third_image = third_image.enhance(0.5)

third_image = ImageEnhance.Brightness(third_image)
third_image = third_image.enhance(2)

third_image = third_image.filter(ImageFilter.FIND_EDGES)
third_image = third_image.filter(ImageFilter.GaussianBlur(radius=2))


red_grayscale_third_image.show()
blue_grayscale_third_image.show()
third_image.show()