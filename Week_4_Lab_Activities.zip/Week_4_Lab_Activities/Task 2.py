
from PIL import Image
# import an image
file_name = 'pillow_practice/cat.jpg'

image = Image.open(file_name)
img_rotated = image.rotate(30)
img_rotated.save('Task2 cat.png', 'PNG')

img_rotated.show()
