from tarfile import symlink_exception

from PIL import Image
from PIL.ImageOps import crop

file_image = "Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG"
image = Image.open(file_image)

image = image.transpose(Image.Transpose.ROTATE_180)
image = image.rotate(290)
image = image.crop ((200,100,400,400))
image = image.resize((4900, 3800))

image.show()

file_second = "Assets/Insects/1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG"
sec_image = Image.open(file_second)

sec_image = sec_image.transpose(Image.Transpose.ROTATE_270).rotate(270).crop((300,150,600,600))

sec_image.show()

file_third = "Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG"
third_image = Image.open(file_third)

third_image = third_image.transpose(Image.Transpose.ROTATE_90).rotate(20). resize((4900, 3800))

third_image.show()